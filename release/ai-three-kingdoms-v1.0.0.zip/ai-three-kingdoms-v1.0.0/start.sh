#!/bin/bash
# AI 삼국지: 적벽대전 — 서버 시작
cd "$(dirname "$0")"
node server/index.mjs
