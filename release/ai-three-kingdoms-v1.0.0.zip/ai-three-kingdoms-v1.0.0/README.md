# AI 삼국지: 적벽대전 v1.0

AI 책사(제갈량)와 함께하는 턴제 전략 게임.

## 실행 방법

**필요**: Node.js 18+ (https://nodejs.org)

### macOS
`start.command` 더블클릭 또는:
```bash
./start.sh
```

### Windows
`start.bat` 더블클릭 또는:
```cmd
start.bat
```

### Linux
```bash
./start.sh
```

브라우저가 자동으로 열립니다. 열리지 않으면 http://localhost:3001 에 접속하세요.

## AI 설정

첫 실행 시 브라우저에서 설정 마법사가 표시됩니다.

- **Ollama (무료/로컬)**: https://ollama.com 에서 설치 후 `ollama pull qwen3:8b`
- **Cloud API**: Claude, OpenAI, Gemini 지원 (API 키 필요)

또는 `.env.example`을 `.env`로 복사하여 사전 설정할 수 있습니다.

## 4개국어 지원

한국어 / English / 中文 / 日本語

---
https://github.com/JihoonJeong/ai-three-kingdoms
